<?php
session_start();
include "connect.php" ;

$login = $_POST["email"];
$pwd = $_POST["password"];
$trouve=false;
$sql = "SELECT * FROM `user`";
$RESULTAT=$db->query($sql);
$resultat=$RESULTAT->fetchALL(PDO::FETCH_ASSOC);

for($i=0;$i<count($resultat);$i++){

  if ($resultat[$i]["email"] == $login && $resultat[$i]["password"] == $pwd){
       $_SESSION["login"]=$resultat[$i]["email"];
      $trouve=true;
  }
   
}
if($trouve){
    header('Location:user.php');
}else{
   
        	echo"<script>
            alert('veuillez vérifier votre email ou password');
            window.location='index.php'
            </script>";

}
    

?>