<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Users</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="table/vendor/bootstrap/css/bootstrap.min.css">

	<link rel="stylesheet" type="text/css" href="vendor/font-awesome-4.7/css/font-awesome.min.css">

	<link rel="stylesheet" type="text/css" href="table/vendor/animate/animate.css">

	<link rel="stylesheet" type="text/css" href="table/vendor/select2/select2.min.css">

	<link rel="stylesheet" type="text/css" href="table/vendor/perfect-scrollbar/perfect-scrollbar.css">

	<link rel="stylesheet" type="text/css" href="table/css/util.css">
	<link rel="stylesheet" type="text/css" href="table/css/main.css">
</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
				<div class="wrap-table100" id="tableuser">
				<div class="table100 ver1 m-b-110">
                    <!--head-->
					<div class="table100-head">
						<table>
							<thead>
								<tr class="row100 head">
									<th class="cell100 column1">Cin</th>
									<th class="cell100 column2">Nom</th>
									<th class="cell100 column3">Prenom</th>
									<th class="cell100 column4">Email</th>
									<th class="cell100 column5">Gendre</th>
								</tr>
							</thead>
						</table>
					</div>
                    <!--body-->
					<div class="table100-body js-pscroll">
						<table>
							<tbody>
                                
                        <?php 
                        include 'connect.php';

                        $req = "SELECT `Cin`, `Nom`, `Prenom`, `email`,`sexe` FROM `user`";
                        $R=$db->query($req);
                        $r=$R->fetchAll(PDO::FETCH_ASSOC);
                              for($i=0;$i<count($r);$i++){
                                   echo"<tr class='row100 body'>";
                                  foreach($r[$i] as $v){
                                      echo"<td class='cell100 column1'>".$v."</td>";
                                  }
                                  echo"</tr>";
                              }
                       
                       ?>


								
							</tbody>
						</table>
					</div>
				</div>
				
				
			</div>
            <button type="button" class="btn btn-primary" onclick="exportTableToExcel('tableuser','users')">Export To Excel </button>
		</div>
	</div>

<script>
    function exportTableToExcel(tableuser, filename = 'users'){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableuser);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    // Specify file name
    filename = filename?filename+'.xls':'excel_data.xls';
    
    // Create download link element
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob( blob, filename);
    }else{
        // Create a link to the file
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
    
        // Setting the file name
        downloadLink.download = filename;
        
        //triggering the function
        downloadLink.click();
    }
}
    </script>
<!--===============================================================================================-->	
	<script src="table/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="table/vendor/bootstrap/js/popper.js"></script>
	<script src="table/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="table/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="table/vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
	<script>
		$('.js-pscroll').each(function(){
			var ps = new PerfectScrollbar(this);

			$(window).on('resize', function(){
				ps.update();
			})
		});
			
		
	</script>
<!--===============================================================================================-->
	<script src="table/js/main.js"></script>

</body>
</html>