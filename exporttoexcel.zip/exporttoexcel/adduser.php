<?php 
session_start();
include 'connect.php';

   
    if ( $_POST['pwd'] != $_POST['pwd1'] )
{
    
        echo"<script>
            alert('veuillez vérifier votre email ou password');
            window.location='register.php'
            </script>";
     
    }
   else{
$cin=$_POST["cin"];
$nom = $_POST["nom"];
$prenom = $_POST["prenom"];
$date = $_POST["date"];
$sexe = $_POST["sexe"];
$email= $_POST["email"];
$pwd= $_POST["pwd"];
$adresse = $_POST["adresse"];
$ville = $_POST["ville"];
$sql="SELECT `Cin` FROM `user` where `Cin` ='$cin'";
$data=$db->query($sql);
$r=$data->fetch(PDO::FETCH_ASSOC);
if(empty($r))
{
    $req = "INSERT INTO `user`(`Cin`, `Nom`, `Prenom`, `email`, `password`, `date`, `sexe`, `adresse`, `ville`) VALUES ('$cin', '$nom', '$prenom', '$email', '$pwd', '$date', '$sexe ', '$adresse', '$ville')";
  $query = $db->prepare($req);
    if($query->execute()){
        
     header('Location:user.php');
    
    }
}

    
       else{
          $_SESSION["exist"]="true";
        $_SESSION["email"]=$email;
           
           echo"<script>
            alert('Account already exist!');
            window.location='index.php'
            </script>";
       }

}
   

?>
