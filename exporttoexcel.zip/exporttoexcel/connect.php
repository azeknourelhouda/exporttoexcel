<?php
$host = 'localhost';
$dbname = 'statistique';
$username = 'root';
$password = '';

try {

    $db = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);

} catch (PDOException $e) {

    die("Impossible de se connecter à la base de données $dbname :" . $e->getMessage());

}
?>